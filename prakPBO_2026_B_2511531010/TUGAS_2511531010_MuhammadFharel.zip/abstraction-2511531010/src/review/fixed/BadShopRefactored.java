package review.fixed;

import java.util.ArrayList;
import java.util.List;

public class BadShopRefactored {

    public static final class Address {
        private final String street;
        private final String city;

        public Address(String street, String city) {
            this.street = street;
            this.city = city;
        }

        public String getStreet() { return street; }
        public String getCity() { return city; }

        @Override
        public String toString() {
            return street + ", " + city;
        }
    }

    public static abstract class Product {
        private final String name;
        private final long price;

        public Product(String name, long price) {
            this.name = name;
            this.price = price;
        }

        public String getName() { return name; }
        public long getPrice() { return price; }
        public long getFinalPrice() { return price; }
    }

    public static class PhysicalProduct extends Product {
        private final int weightGrams;

        public PhysicalProduct(String name, long price, int weightGrams) {
            super(name, price);
            this.weightGrams = weightGrams;
        }

        public int getWeightGrams() { return weightGrams; }
    }

    public static class DigitalProduct extends Product {
        public DigitalProduct(String name, long price) {
            super(name, price);
        }
    }

    public static abstract class ShippingService {
        public abstract long ratePerKg();

        public final long calculateCost(int weightGrams) {
            long kg = (weightGrams + 999L) / 1000;
            return kg * ratePerKg();
        }
    }

    public static class ExpressShipping extends ShippingService {
        @Override
        public long ratePerKg() {
            return 18000; // Perbaikan: tarif Ekspres
        }
    }

    public interface PaymentMethod {
        boolean pay(long amount);
    }

    public static class Voucher implements PaymentMethod {
        private long balance;

        public Voucher(long balance) {
            this.balance = balance;
        }

        @Override
        public boolean pay(long amount) {
            if (amount <= balance) {
                balance -= amount;
                return true;
            }
            return false;
        }

        public long getBalance() { return balance; }
    }

    public static void main(String[] args) {
        PhysicalProduct p1 = new PhysicalProduct("Kopi", 85000, 300);
        PhysicalProduct p2 = new PhysicalProduct("Rendang", 120000, 400);

        List<Product> cart = List.of(p1, p2);
        long total = p1.getFinalPrice() + p2.getFinalPrice();
        System.out.println("Total cart: " + total);

        ShippingService express = new ExpressShipping();
        int totalWeight = p1.getWeightGrams() + p2.getWeightGrams();
        System.out.println("Ongkir Ekspres 2 kg: " + express.calculateCost(totalWeight));

        Address addr1 = new Address("Jl. Sudirman 10", "Padang");
        Address addr2 = new Address("Jl. Sudirman 10", "Bukittinggi");

        System.out.println("ORD-1> " + addr1);
        System.out.println("ORD-2> " + addr2);

        DigitalProduct flashSaleEbook = new DigitalProduct("E-Book Flash Sale", 70000);
        System.out.println("Harga flash sale: " + flashSaleEbook.getFinalPrice());

        Voucher voucher = new Voucher(140000);
        boolean success = voucher.pay(flashSaleEbook.getFinalPrice());
        System.out.println(success + " | sisa Rp" + voucher.getBalance());
    }
}